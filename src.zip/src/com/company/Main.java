package com.company;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

public class Main {

    public static void main(String[] args) {

        jade.core.Runtime rt = jade.core.Runtime.instance();
        Profile p = new ProfileImpl();
        AgentContainer mc = rt.createMainContainer(p);
        try {
            AgentController rma = mc.createNewAgent("rma", "jade.tools.rma.rma", null);
            rma.start();
            AgentController ac = mc.createNewAgent("John", "com.company.FirstAgent", null);
            System.out.println(ac.getState() + "!");
            ac.start();
            mc.createNewAgent("Jane", "com.company.SecondAgent", null).start();
            mc.createNewAgent("Peter", "com.company.SecondAgent", new Object[]{Integer.valueOf(1)}).start();
            mc.createNewAgent("Costica", "com.company.SecondAgent", new Object[]{Integer.valueOf(2)}).start();

            System.out.println(ac.getState() + "!");
        } catch (StaleProxyException e) {
            e.printStackTrace();
        }

    }
}