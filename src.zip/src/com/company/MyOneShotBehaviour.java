package com.company;

import jade.core.behaviours.OneShotBehaviour;

public class MyOneShotBehaviour extends OneShotBehaviour {

    /**
     *
     */
    private static final long serialVersionUID = 1L;


    @Override
    public void action() {
        // TODO Auto-generated method stub

    }

}
